/****
	  antix.h
		Clone this package from git://github.com/rtv/Antix.git
	  version 2
	  Richard Vaughan  
****/

#include <vector>
#include <set>
#include <list>
#include <math.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>

#define GRAPHICS 1
#define DEBUG 1
#define WRITE 1

// handy STL iterator macro pair. Use FOR_EACH(I,C){ } to get an iterator I to
// each item in a collection C.
#define VAR(V,init) __typeof(init) V=(init)
#define FOR_EACH(I,C) for(VAR(I,(C).begin());I!=(C).end();I++)

namespace Antix
{
  /** Convert radians to degrees. */
  inline double rtod( double r ){ return( r * 180.0 / M_PI ); }
  /** Convert degrees to radians */
  inline double dtor( double d){ return( d * M_PI / 180.0 ); }
  	
	class Home
	{
	public:
		
		class Color
		{
		public:
			double r, g, b;
			
		Color( double r, double g, double b ) :	r(r), g(g), b(b) {}
			
			// get a random color
			static Color Random()
			{
				return Color( drand48(), drand48(), drand48() );
			}
			
		} color; 
		
		double x, y, r;
		
		Home( const Color& color, double x, double y, double r );
	};
	class Source
	{
	public:
		
		class Color
		{
		public:
			double r, g, b;
			
		Color( double r, double g, double b ) :	r(r), g(g), b(b) {}
			
			// get a random color
			static Color Random()
			{
				return Color( drand48(), drand48(), drand48() );
			}
			
		} color; 
		
		double x, y, r;
		unsigned int id;
		double *parameter_k;
		double *parameter_b;
		double k,b;
		double opt_n;
		int parameter_index;
		int real_robots;
		int num_robots; // for strategy 1
		int init_time;
		double round_trip;
		 int p0;
		 int p;
		// int s_id;
		 int low;
		int high;
		double dis;
		long sleep_time;
		Source( const Color& color, double x, double y, double r );
		void Init();
		void balance();
		void delete_puck();
		
		int get_puck();
		bool safe();
		int update_puck();
		
	};

  class Robot
  {
  public:

	 /** initialization: call this before using any other calls. */	
	 static void Init( int argc, char** argv );

	 static void UpdateGui();

	 /** update all robots */
	 static void UpdateAll();

	 /** Normalize a length to within 0 to worldsize. */
	 static double DistanceNormalize( double d );

	 /** Normalize an angle to within +/_ M_PI. */
	 static double AngleNormalize( double a );
	 
	 /** Wrap distances around the torus */
	 static double WrapDistance( double d );

	 /** Start running the simulation. Does not return. */
	 static void Run();

	 static bool paused; // runs only when this is false
	 static bool show_data; // controls visualization of pixel data
	 static double fov;      // sensor detects objects within this angular field-of-view about the current heading
	 static double pickup_range;
	 static double radius; // radius of all robot's bodies
	 static double range;    // sensor detects objects up tp this maximum distance
	 static double worldsize; // side length of the toroidal world
	 static std::vector<Home*> homes;
	 static std::vector<Source*> sources;
	 static std::vector<Robot*> population;
	 static uint64_t updates; // number of simulation steps so far	 
	 static uint64_t updates_max; // number of simulation steps to run before quitting (0 means infinity)
	 static unsigned int home_count; // number of home zones
	 static unsigned int home_population; // number of robots
	 static unsigned int puck_count; // number of pucks that exist in the world
	 static unsigned int sleep_msec; // number of milliseconds to sleep at each update
	static unsigned long long puck_id;
	static unsigned int source_id;
	static unsigned int robot_id;
	static unsigned int strategy;
	static unsigned int anneal;
	static unsigned int environment;
	static unsigned int random_position;
	static unsigned long long pucks_collected;
	static bool isgraphics;
	static FILE *file_robot;

#if GRAPHICS
	 static int winsize; // initial size of the window in pixels

	 /** initialization: call this before using any other calls. */	
	 static void InitGraphics( int argc, char* argv[] );

	 /** render all robots in OpenGL */
	 static void DrawAll();

	 // render the robot in OpenGL
	 void Draw();	 
#endif
	 
	 // deliver pucks to this location
	 Home* home;
	Source* source;
	 std::list <int> history;
	long last_home_time;
	long real_work_time;
	long pick_time;
	long drop_time;
	long sleep_time;
	long switch_number;
	long count_time;
	bool seepuck_my_goal;
	bool fast_speed;
	long *min_pucks;
	long *max_pucks;
	long init_time;
	//bool switch_task;
	unsigned int r_id;
	
	double getWorkTime()
	{
		if(source!= NULL)
			return 1.0/( ( source->round_trip + 10 + 8 + sleep_time) *1.0);
		return 0.0;
	}
	long getRealWorkTime()
	{
		if(real_work_time < 0)
			return 9999999;
		else
			return real_work_time;
	}
	void setRealWorkTime(long time)
	{
		if(last_home_time == -1)
		{
			last_home_time = time;
			real_work_time = -1;
		}
		else
		{
			real_work_time = time - last_home_time;
			last_home_time = time;
		}
		return;
	}

	static char *getFileName(char name[])
	{
		char *s;
		s = (char *)malloc(50*sizeof(char));
		//s=NULL;
		char buffer[5];
		strcpy(s,"");
		strcat(s,name);
		strcat(s,"a");
		sprintf(buffer,"%d",puck_count);
		strcat(s,buffer);
		strcat(s,"p");
		sprintf(buffer,"%d",home_population);
		strcat(s,buffer);
		strcat(s,"t");
		sprintf(buffer,"%d",( strategy==2?2:(strategy+anneal*2) ) );
		strcat(s,buffer);
		strcat(s,"b");
		sprintf(buffer,"%d",random_position);
		strcat(s,buffer);
		strcat(s,"e");
		sprintf(buffer,"%d",environment);
		strcat(s,buffer);
		strcat(s,".txt");
		return s;
	}

	bool wait_start()
	{
		if(init_time > 0)
		{
			init_time --;
			return true;
		}
		return false;
	}
	bool wait_for()
	{
		
		if(count_time > 0)
		{
			count_time--;
			return true;
		}
		return false;
		
	}
	void balance_sleep_time()
	{//this function is only centralized method
		if(strategy == 2)
		{
			if(source == NULL)
			{
				#if DEBUG
					printf("source is NULL in balance_sleep_time function\n");
				#endif
			}
			else
				sleep_time = source->sleep_time;
		}
	}
	void reset_sleep_time()
	{
		sleep_time = 0;
	}
	void init_sleep_time()
	{
		sleep_time = sleep_time + switch_number*switch_number * 200;
	}
	void set_sleep_time()
	{
		count_time = sleep_time;
	}
	void set_pick_time()
	{
		count_time = pick_time;
	}
	void set_drop_time()
	{
		count_time = drop_time;
	}
	long my_pow(long x, long n)
	{
		long res=1;
		for(long i=1; i<=n; i++)
			res = res * x;
		return res;
	}
	bool switch_all()
	{
		if(switch_number >= 4)
		{
			#if DEBUG
				printf("switch all %ld\n",switch_number);
			#endif
			return true;
		}
		for(unsigned int i=0; i<=puck_count; i++)
		{
			if(max_pucks[i] <= min_pucks[i])
				return false;
		}
		#if DEBUG
			printf("switch all\n");
		#endif
		return true;
	}
	bool good_to_pick(int index, int num)
	{
		if(source==NULL)
		{
			if(max_pucks[index] > min_pucks[index])
			{
				int tmp = ( max_pucks[index] + min_pucks[index] )/2;
				if(num < tmp)
					return false;
			}
		}
		return true;
	}
	int com_centralized()
	{
		double tmp=0.0;
		double mid = 50.0;
		double aver=0.0;
		if(source == NULL)
		{
			#if DEBUG
				printf("source = NULL in com_centralized function\n");
			#endif
		}
		else
		 	mid = (source->k)/(2*source->b);
		std::list <int>::iterator itr;
		for(itr = history.begin(); itr!=history.end(); itr++)
		{
			tmp = tmp + (*itr);
		}
		aver = tmp /(1.0* history.size() );
		double var =0.0;
		for(itr = history.begin(); itr!=history.end(); itr++)
		{
			var = var + ((*itr) - 50)*((*itr) - 50);
		}
		var = sqrt( var / (1.0*history.size()) );
		double relative_var=0.0;
		relative_var = var / 50.0;
		int now = history.front();
		int size = history.size();
		double inc = 2.0;//1.0;//1.74
		double dec = 1.0;//0.4;//0.92
		//now = aver;
		relative_var=0;
		if( ( size  > 0) )
		{
		if( now < ( mid ))
		{
			//if( (now+2.5) < aver)
			//	relative_var = relative_var *0.5;
			if( 2*( mid - now ) > ( now - source->low) )
				sleep_time = sleep_time + (long) (inc *my_pow( mid- now, 1) *(1.0 + relative_var));
			else
				sleep_time = sleep_time + (long) (inc *my_pow( mid - now,  1 ) *(1.0 + relative_var));
			return 1;
		}
		else if( now > ( mid ))
		{
			//if( ( now-2.5) > aver)
			//	relative_var = relative_var *0.5;
			if( ( now - mid) > (source->high - now) )
				sleep_time = sleep_time - (long) ( dec *my_pow( now - mid,  1 ) *(1.0 + relative_var));
			else
				sleep_time = sleep_time - (long) ( dec * my_pow( now - mid, 1 ) *(1.0 + relative_var));
			if(sleep_time < 0)
				sleep_time = 0;
			return -1;
		}
		}
		return 0;
	}
	int com_distributed()
	{
		if(source == NULL)
		{
			#if DEBUG
				printf("[ERROR] com_distributed source is null\n");
			#endif
			return 0;
		}
		double tmp=0.0;
		double aver=0.0;
		double var=0.0;
		double inc = 1.5;//1.74
		double dec = 0.9;//0.92
		std::list <int>::iterator itr;
		for(itr = history.begin(); itr!=history.end(); itr++)
		{
			tmp = tmp + (*itr);
		}
		aver = tmp /(1.0* history.size());
		tmp =0.0;
		for(itr = history.begin(); itr!=history.end(); itr++)
		{
			tmp = tmp + ( (*itr) - aver ) * ( ( *itr ) - aver ) ;
		}
		var = sqrt(tmp/(1.0*history.size()));
		int size = history.size();
		double relative_var = var / aver;
		long d_pucks = max_pucks[source->id] - min_pucks[source->id];
		int offset=5;
		int now = history.front();
		int mid = ( max_pucks[source->id] + min_pucks[source->id])/2;
		int large=1;my_pow( (switch_number)/4+1,2) ;
		#if DEBUG
			//printf("S:%d,R:%d,old:%ld->",source->id,r_id,sleep_time);
		#endif
		if(size>= 1 && ( d_pucks > 40 ) /*|| (switch_number>=4)*/)
		{
		if( now <= ( mid +offset))
		{
			
			if( ( mid + offset - now ) > ( now - min_pucks[source->id]) )
				sleep_time = sleep_time + (long) inc *my_pow( mid+offset - now,  2 ) *(1.0 + relative_var)*large;
			else
				sleep_time = sleep_time + (long) inc *my_pow( mid+offset - now,  1 ) *(1.0 + relative_var)*large;
			//return 1;
		}
		else if( now > ( mid + offset))
		{
			
			if( ( now - mid) > (max_pucks[source->id] - now) )
				sleep_time = sleep_time - (long) ( dec *my_pow( now - mid,  2 ) *(1.0 + relative_var))*large;
			else
				sleep_time = sleep_time - (long) ( dec * my_pow( now - mid, 1 ) *(1.0 + relative_var))*large;
			if(sleep_time < 0)
				sleep_time = 0;
			//return -1;
		}
		}
		#if DEBUG
			///printf("new:%ld\n",sleep_time);
		#endif
		return 0;
	}/*
	int com_centralized_old()
	{
		double tmp=0.0;
		double mid = 50.0;
		double aver=0.0;
		if(source == NULL)
		{
			#if DEBUG
				printf("source = NULL in com_centralized function\n");
			#endif
		}
		else
		 	mid = (source->k)/(2*source->b);
		std::list <int>::iterator itr;
		for(itr = history.begin(); itr!=history.end(); itr++)
		{
			tmp = tmp + (*itr);
		}
		aver = tmp /(1.0* history.size() );
		//if(drand48() < 0.5)
		{
		if( (history.front() < (source->low + 10) ))
		{
				
			sleep_time = ( sleep_time + 20 ) *4 ;
			return 1;
				
		}
		else if( (history.front() < (source->low + 20) ))
		{
				
			sleep_time = ( sleep_time + 20 ) *2 ;
			return 1;
				
		}
		else if(history.front() < (mid - 10 ))
		{
			sleep_time = (sleep_time+20)*2 + (long)(mid - history.front())*2;
			return 1;
		}
		else if(history.front() < (mid))
		{
			sleep_time = sleep_time + (long)(mid - history.front());
			return 1;
		}
		
		else if ((history.front() > source->high -20) && history.front() > (aver+2.5) )
		{
				
				sleep_time = sleep_time /4 ;
				if(sleep_time < 0)
					sleep_time =0;
				return -1;
		}
		else if(history.front() > (mid+10) && history.front() > (aver+5) )
		{
			sleep_time = sleep_time / 2;//- (long)(history.front()-mid)/2;
				if(sleep_time < 0)
					sleep_time =0;
				return -1;
		}
		else if(history.front() > (mid) && history.front() > (aver+5) )
		{
			sleep_time = sleep_time - (long)(history.front()-mid);
				if(sleep_time < 0)
					sleep_time =0;
				return -1;
		}
		else
				return 0;
		}
		return 0;
	}*/
	/*
	int com_distributed_right()
	{
		double tmp=0.0;
		double aver=0.0;
		double var=0.0;
		std::list <int>::iterator itr;
		for(itr = history.begin(); itr!=history.end(); itr++)
		{
			tmp = tmp + (*itr);
		}
		aver = tmp /(1.0* history.size());
		tmp =0.0;
		for(itr = history.begin(); itr!=history.end(); itr++)
		{
			tmp = tmp + ( (*itr) - aver ) * ( ( *itr ) - aver ) ;
		}
		var = sqrt(tmp/(1.0*history.size()));
		int size = history.size();
		long d_pucks = max_pucks - min_pucks;
		bool small = false;
		if((history.front() - min_pucks) >= (max_pucks - history.front()) )
			small = true;
		if(small && ((history.front() < aver -5) ||((d_pucks > 30) && history.front() < (min_pucks+ 15) && size>3) ))
		{
				
			sleep_time = (sleep_time + 80) * 4;
			return 1;
				
		}
		else if(  small && ((history.front() < aver -2.5) || ((d_pucks > 30) && history.front() < (min_pucks + 25) && size > 3)) )
		{
				
			sleep_time = (sleep_time + 80) * 2;
			return 1;
				
		}
		
		else if ((history.front() > aver + 5) || ( (history.front() > (max_pucks - 30)) && (size > 2) ) )
		{
			#if DEBUG
				//printf("%ld,%ld,%d\n",min_pucks,max_pucks,history.front());
			#endif
				sleep_time =0;// sleep_time/8;//sleep_time /16;
				if(sleep_time < 0)
					sleep_time =0;
				return -1;
		}
		else if ((history.front() > aver + 2.5) || (history.front() > (max_pucks - 40) && size > 2))
		{
				
				sleep_time = sleep_time /4;
				if(sleep_time < 0)
					sleep_time =0;
				return -1;
		}
		else if ((history.front() > aver ) )
		{
				
				sleep_time = sleep_time -20;
				if(sleep_time < 0)
					sleep_time =0;
				return -1;
		}
		else if( (history.front() < (aver-1) )  )
		{
				
			sleep_time = (sleep_time + 20) ;
			return 1;
				
		}
		else
				return 0;
	}*/
	int isAtSource(double _x,double _y)
	{
		double dx(WrapDistance( source->x - _x ));
		double dy(WrapDistance( source->y - _y ));
		if( ( fabs(dx) + fabs(dy) ) < 2*source->r)
			return 1;
		return 0;
	}
	void push_queue(int n, unsigned int index)
	{
		if(index < 1 || index > puck_count)
		{
			#if DEBUUG
				printf("[ERROR] index not correct %d\n",index);
			#endif
			return ;
		}
		if(n > max_pucks[index])
			max_pucks[index] = n;
		if(n < min_pucks[index])
			min_pucks[index] = n;
		if(source!=NULL)
		{
			history.push_front(n);
			while(history.size() > 5)
			{
				history.pop_back();
			}
		}
	}
	void clean_queue()
	{
		history.clear();
		//max_pucks=0;
		//min_pucks=100;
	}
	bool cal()
	{
		
		double tmp=0.0;
		std::list <int>::iterator itr;
		for(itr = history.begin(); itr!=history.end(); itr++)
		{
			tmp = tmp + (*itr);
		}
		if (source != NULL)//20
			if( ( source->p < (source->low +2) ) || (history.front() < (tmp/(1.0*history.size()) - 15)))
				return true;
		return false;
	}
		class Pose
		{
		public:
			double x,y,a; // 2d position and orientation
			
		Pose( double x, double y, double a ) : x(x), y(y), a(a) {}
		Pose() : x(0.0), y(0.0), a(0.0) {}
			
			// get a random pose 
			static Pose Random()
			{
			  return Pose( drand48() * Robot::worldsize, 
								drand48() * Robot::worldsize, 
								Robot::AngleNormalize( drand48() * (M_PI*2.0)));
			}
		} pose; // instance: robot is located at this pose
		
		class Speed
		{		
		public:
			double v; // forward speed
			double w; // turn speed
	  	
			// constructor sets speeds to zero
		Speed() : v(0.0), w(0.0) {}		
		} speed; // instance: robot is moving this fast
		
		class SeeRobot
		{
		public:
		  const Home* home;
		  Pose pose;
		  Speed speed;
		  double range;
		  double bearing;
		  bool haspuck;
			
		SeeRobot( const Home* home, const Pose& p, const Speed& s, const double range, const double bearing, const bool haspuck )
		  : home(home), pose(p), speed(s), range(range), bearing(bearing), haspuck(haspuck)
			{ /* empty */}
	 };
	 
	 /** A sense vector containing information about all the robots
			 detected in my field of view */
	 std::vector<SeeRobot> see_robots;

	public: class Puck
	 {
	 public:
		 double x, y;
		unsigned long long p_id;
		unsigned int s_id;
		 bool held;
		bool home;//zhao june 10
		Source *source;
		 /** constructor places a puck at specified pose */
		 //Puck( double x, double y ) : x(x), y(y), held(false) {}
		 
		 /** default constructor places puck at random pose */
	 Puck() 
		 : x(drand48()*worldsize), y(drand48()*worldsize), held(false), home(false) //zhao june 10
			 { /* empty */ }
		~Puck() { source=NULL;}
		void Init(Source *tmps,int ss_id,double tmpx, double tmpy, double tmpr)
		{
			x = DistanceNormalize( tmpx - tmpr + 1.9 * tmpr * drand48());
			y = DistanceNormalize( tmpy - tmpr + 1.9 * tmpr * drand48());
			source = tmps;
			held = false;
			home = false;
			p_id = puck_id;
			puck_id++;
			s_id = ss_id;
			if ( fabs(WrapDistance(x - tmpx)) + fabs(WrapDistance(y-tmpy)) > 2*tmpr)
			{
				#if DEBUG
					printf("puck %llu construct fail!\n",p_id);
				#endif
			}
			
		}
		 
	 };		 
	 
	 static std::list<Puck> pucks;

	 class SeePuck
	 {
	 public:
		 Puck* puck;
		 double range;
		 double bearing;		 
		 bool held;
		bool home;
		Source *source;
		 
	 SeePuck( Puck* puck,  const double range, const double bearing, const bool held, const bool home, Source* source )
		 : puck(puck), range(range), bearing(bearing), held(held), home(home), source(source)
		 { /* empty */}
	 };
	 
	 /** A sense vector containing information about all the pucks
			 detected in my field of view */
	 std::vector<SeePuck> see_pucks;	 
	 
	 	 
	 // constructor
	 Robot( Home* home, Source *source,
							const Pose& pose );
	 
	 // destructor
	 virtual ~Robot() {}
	 
	 /** Attempt to pick up a puck. Returns true if one was picked up,
			 else false. */
	 int Pickup(); 
	 
	 /** Attempt to drop a puck. Returns true if one was dropped, else
			 false. */
	 int Drop(int flag);
	 
	 /** Returns true if we are currently holding a puck. */
	 bool Holding();

	//bool IsHome(const Puck& p);
	  
	 /** pure virtual - subclasses must implement this method  */
	 virtual void Controller() = 0;

	private:
	 Puck* puck_held;
	 
	 // move the robot
	 void UpdatePose();
	 
	 // update
	 void UpdateSensors();
  };	
}; // namespace Antix
