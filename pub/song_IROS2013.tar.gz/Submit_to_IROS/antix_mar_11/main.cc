
#include "controller.h"
using namespace Antix;

Home::Color colors[] = { Home::Color(0,0,1), 
												 Home::Color(0,0.5,0), // darker green 
												 Home::Color(0.3,0.3,1),  // lighter blue
												 Home::Color(1,1,0), 
												 Home::Color(1,0,1), 
												 Home::Color(0,1,1), 
												 Home::Color(1,0,1) };
												 
Source::Color colors1[] = { Source::Color(0.3,0.3,1), //red
				Source::Color(0,0,0),
				Source::Color(1,0,0),
												 Source::Color(0,0.7,0), // darker green 
												 Source::Color(0.3,0.3,1),  // lighter blue
												 Source::Color(1,1,0), 
												 Source::Color(1,0,1), 
												 Source::Color(0,1,1), 
												 Source::Color(1,0,1) };											
/*
Source::Color colors1[] = { Source::Color(1,0,0), //red
												 Source::Color(0,0.5,0), // darker green 
												 Source::Color(0.3,0.3,1),  // lighter blue
												 Source::Color(1,1,0), 
												 Source::Color(1,0,1), 
												 Source::Color(0,1,1), 
												 Source::Color(1,0,1) };
*/
size_t color_count = 7;


int main( int argc, char* argv[] )
{
  // configure global robot settings
  Robot::Init( argc, argv );
	char file[3][15]={"file_robot","file_puck","file_work"};
	Robot::file_robot= fopen(Robot::getFileName(file[0]),"w");
	//Robot::file_puck= fopen(Robot::getFileName(file[1]),"w");
	//Robot::file_work= fopen(Robot::getFileName(file[2]),"w");
	Home *hh = NULL;
	// create each home, and each robot within each home
  for( unsigned int i=0; i<Robot::home_count; i++ )
		{
			Home* h = new Home( i < color_count ? colors[i] : Home::Color::Random(), 
													i ? drand48() * Robot::worldsize : Robot::worldsize/2.0,
													i ? drand48() * Robot::worldsize : Robot::worldsize/2.0,													
													0.03 );
			hh = h;
			if(Robot::strategy == 1)
			{
				for( unsigned int i=0; i<Robot::home_population; i++ )
					new Forager( h ,NULL);
			}
		}	
	std::vector<double> optimal;
	std::vector<Robot::Pose> check;
	Robot::Pose o(Robot::worldsize/2.0,Robot::worldsize/2.0,0.0);
	check.push_back(o);	
	double x[5]={0.1,0.2,0.7};
	double y[5]={0.1,0.8,0.7};
	for( unsigned int i=0; i<Robot::puck_count; i++ )
		{
			bool run=true;
			double tmpx,tmpy;
			while(run)
			{
				tmpx = drand48() * Robot::worldsize;
				tmpy = drand48() * Robot::worldsize;
				run = false;
				for(unsigned int j=0; j<check.size(); j++)
				{
					double dis = hypot(Robot::WrapDistance(tmpx-check[j].x),Robot::WrapDistance(tmpy-check[j].y));
					double cab_dis = fabs(Robot::WrapDistance(tmpx-check[j].x)) + fabs(Robot::WrapDistance(tmpy-check[j].y));
					if( ( dis < 0.2 ) || ( cab_dis < 0.2 ) )
					{
						run = true;
						break;
					}
				}
			}
			Robot::Pose a(tmpx,tmpy,0);
			check.push_back(a);
			if(Robot::random_position == 2)
			{
				tmpx = x[i]*Robot::worldsize;
				tmpy = y[i]*Robot::worldsize;
			}
			Source* s = new Source( i < color_count ? colors1[i+1] : Source::Color::Random(), tmpx ,tmpy,0.03 );
			s->Init();
			optimal.push_back(s->opt_n);
		}
	if(Robot::strategy == 2)
	{//the centralized method
		double total = 0.0;
		//std::vector<Source*>  std::iterator  it;
		std::vector<int> source_robots;
		for(unsigned int i=0; i<optimal.size(); i++)
			total = total + optimal[i];
		
		
		unsigned int total_tmp=0;
		int array[3]={0,0,20};
		for(unsigned int i=0; i<Robot::sources.size(); i++)
		{
			unsigned int tmp =array[i];// (unsigned int) ((optimal[i])*Robot::home_population/total + 0.5);//array[i];//
			source_robots.push_back(tmp);
			if(i == ( Robot::sources.size() - 1 ))
			{
				Robot::sources[i]->real_robots =Robot::home_population -total_tmp;
				tmp = Robot::sources[i]->real_robots;
			}
			else
				Robot::sources[i]->real_robots = tmp;
			Robot::sources[i]->balance();
			for(unsigned int j=0; j< tmp ; j++)
			{
				new Forager( hh ,((Robot::sources[i])));
			}
			total_tmp = total_tmp + tmp;
			
		}
		if (total_tmp != Robot::home_population)
			{
				#if DEBUG
					printf("[ERROR]robots: %d != %d\n",total_tmp,Robot::home_population);
				#endif
			}
		//printf("robot number :%d, real number%d\n",Robot::home_population, total_tmp);
	}
  // and start the simulation running
  Robot::Run();
  fclose(Robot::file_robot);
  // we'll probably never get here, but this keeps the compiler happy.
  return 0;
}
