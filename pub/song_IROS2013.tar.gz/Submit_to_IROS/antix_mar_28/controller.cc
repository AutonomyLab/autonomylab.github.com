/*****
		controller.cc
		version 1
		Copyright Richard Vaughan, 2009.09.09
****/

#include <math.h>
#include "controller.h"
using namespace Antix;

void Forager::Controller()
{		
	double heading_error(0.0);
	
	// distance and angle to home
	double dx( WrapDistance( home->x - pose.x ));	 	 
	double dy( WrapDistance( home->y - pose.y ));		  
	double da( atan2( dy, dx ));
	double dist( hypot( dx, dy ));
	if(strategy==2 && state==5)
	{
		speed.v=0;
		speed.w=0;
		if(!wait_start())
			state = 0;
		return;
	}
	if(state == 1)
	{
		speed.v=0;
		speed.w=0;
		if(!wait_for())
			state = 0;
		return;
	}
	else if (state == 2)
	{
		speed.v =0;
		speed.w=0;
		if(!wait_for())
		{
			/*if(switch_task)
			{
				switch_task = false;
				state =0;
			}
			else*/
				state = 3;
			set_sleep_time();
		}
		return;
	}
	else if(state == 3)
	{//sleep
		speed.v=0;
		speed.w=0;
		if(!wait_for())
		{
			state = 0;
			setRealWorkTime(updates);
		}
		return;
	} 
	
	if( Holding() || state == 4)
		{ // drive home		  
			// turn towards home		  
			heading_error = AngleNormalize( da - pose.a );// < 0  ? 0.05 : -0.05;
			
			// if we're some random distance inside the home radius
			if( dist < drand48() * home->r )
			{
				int tmp_drop;
				//if(state == 4)
				tmp_drop = Drop(state);
				
				if(tmp_drop >= 1)
				{
					state = 2;
					set_drop_time();
					if(tmp_drop==2 && strategy ==1 )
					{
						//int a = random()%3;
						//source = ;
						//lastx = Robot::sources[a]->x;
						//lasty = Robot::sources[a]->y;
						//source->num_robots++;
						//change in May 9
						count_time =500;
						lastx = home->x;
						lasty = home->y;
						
					} // release the puck (implies we won't be holding
				}
				if(state == 4)
				{
					#if BEBUG
						printf("state is still 4\n");
					#endif
				}
			}
			// next time round)
		}
	else // not holding
		{
			// if I see any pucks and I'm away from home
			if(state<7 && seepuck_my_goal && see_pucks.size() > 0 && dist > home->r )
				{
					// find the angle to the closest puck that is not being carried
					double closest_range(1e9); //BIG				
					FOR_EACH( it, see_pucks )
						{
							if( it->range < closest_range && !it->held)						 
								{
									heading_error = it->bearing;
									closest_range = it->range; // remember the closest range so far
								}
						}
					
					// and attempt to pick something up
					int pickup = Pickup();
					if( pickup == 1)
						{
							// got one! remember where it was
							state = 1;
							set_pick_time();
							lastx = pose.x;
							lasty = pose.y;
						}
					else if(pickup == 2)
					{
						if(source!=NULL)
							state = 4;//on the way that back to home	
						else 
						{
							
							state =7;
						}
						#if DEBUG
							if(source!=NULL && strategy == 2)
							printf("source %d robot %d should back home\n",source->id ,r_id);
						#endif			
					}
					else if(pickup == 3)
					{
						if(source == NULL)
						{
							
							state =7;
						}
						#if DEBUG
							//printf("source %d robot %d could not pickup\n",source->id ,r_id);
						#endif	
					}
				}
			else
				{
					
					
					double lx( WrapDistance( lastx - pose.x ));	 	 
					double ly( WrapDistance( lasty - pose.y ));		  
					
					// go towards the last place I picked up a puck
					heading_error = AngleNormalize( atan2(ly, lx) - pose.a );
					
					// if I've arrived at the last place and not yet found a
					// puck, choose another place 
					if( hypot( lx,ly ) < 0.02 )// old is 0.05
						{
							if(state == 7)
								state =8;
							else if(state ==8)
								state =0;
							
							if(fast_speed == false)
							{
								#if DEBUG
									if(source != NULL)
									printf("source %d robot %d shouldn't go randomly see_puck size %d at %d %d, (%lf,%lf)(%lf,%lf)(%lf,%lf)\n",source->id ,r_id,(int)see_pucks.size(),isAtSource(pose.x,pose.y), isAtSource(lastx,lasty),pose.x,pose.y,source->x,source->y,lastx,lasty);
								#endif 
							}							
							
							lastx += drand48() * 0.4 - 0.2;
							lasty += drand48() * 0.4 - 0.2;
							
							lastx = DistanceNormalize( lastx );//big bug!!
							lasty = DistanceNormalize( lasty );
							#if DEBUG
							if(lastx < 0 || lasty < 0)
								printf("%lf,%lf\n",lastx,lasty);
							#endif
						}
				}
		}
	
	// if I'm pointing in about the right direction
	if( fabs( heading_error ) < 0.1 )
		{
			
			speed.v = 0.005; // drive fast
			speed.w = 0.0; // don't turn
			if(source == NULL || fast_speed)
				speed.v = speed.v * 3.0;// to make it converge fast
			
			else if( see_robots.size() > 0 && closed_robot)
			{
				//speed.v = speed.v - speed.v*0.0001*see_robots.size();
				//speed.w=0.01;
			}
			
		}
	else
			{
				speed.v = 0.001; // drive slowly
				if(source == NULL || fast_speed)
					speed.v = speed.v *3.0;//to make it converge fast
				speed.w = 0.2 * (heading_error); // turn to reduce the error
			}		
}
