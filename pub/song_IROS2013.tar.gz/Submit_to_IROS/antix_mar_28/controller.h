
#include "antix.h"

// this is the robot controller code
class Forager : public Antix::Robot
{
 public:  
  double lastx, lasty;
	int state;  
  
 Forager( Antix::Home* h , Antix::Source *s) 
	 : Robot( h,s, Pose::Random() ), 
		lastx(home->x), // initial search location is close to my home
		lasty(home->y),
		state(0)
			{
	if(strategy == 2)
	{
		if(s!=NULL)
		{
			lastx = s->x;
			lasty = s->y;
			state = 5;
			init_time = s->init_time;
			s->init_time = s->init_time + 10;
		}
		else
		{
			#if DEBUG
				printf("[ERROR], source is null\n");
			#endif
		}
	}	
	}
  
  // must implement this method. Examine the pixels vector and set the
  // speed sensibly.
  virtual void Controller();
};
