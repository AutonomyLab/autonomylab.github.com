/****
   antix.cc
   version 1
   Richard Vaughan  
	 Clone this package from git://github.com/rtv/Antix.git
****/
//./antix -a 3 -p 80 -t 2 -b  2
#include <assert.h>
#include <unistd.h>
#include <memory>
#include <new>

#include "antix.h"
using namespace Antix;

// initialize static members
bool Robot::paused( false );
bool Robot::show_data( false );
double Robot::fov(  dtor(360.0) );//180
double Robot::pickup_range( Robot::range/5.0 );//5.0
double Robot::radius(0.01);
double Robot::range( 0.10 );//0.1
double Robot::worldsize(1.0);
std::vector<Home*> Robot::homes;
std::vector<Robot*> Robot::population;
std::vector<Source*> Robot::sources;
std::list<Robot::Puck> Robot::pucks;
uint64_t Robot::updates(0);
uint64_t Robot::updates_max( 20000 );//10000 
unsigned int Robot::home_count(1);
unsigned int Robot::home_population( 20 );
unsigned int Robot::puck_count(100);
unsigned int Robot::sleep_msec( 10 );
unsigned int Robot::Period(100);
unsigned long long Robot::puck_id(1);
unsigned int Robot::source_id(1);//every source has a source id
unsigned int Robot::robot_id(1);//every robot has a id
unsigned int Robot::strategy(1);//1 is the distributed method, 2 is the centralized method
unsigned int Robot::environment(1);
unsigned int Robot::anneal(0);
unsigned int Robot::random_position(1);
unsigned long long Robot::pucks_collected(0);
bool Robot::isgraphics(true);
double Robot::realWorkTime[4]={0.0001,0.00001,0.00001,0.00001};
FILE *Robot::file_robot; 

const char usage[] = "Antix understands these command line arguments:\n"
	"  -? : Prints this helpful message.\n"
	"  -c <int> : sets the number of pixels in the robots' sensor.\n"
	"  -d  Enables drawing the sensor field of view. Slows things down a bit.\n"
	"  -f <float> : sets the sensor field of view angle in degrees.\n"
	"  -p <int> : set the size of the robot population.\n"
	"  -r <float> : sets the sensor field of view range.\n"
	"  -s <float> : sets the side length of the (square) world.\n"
	"  -u <int> : sets the number of updates to run before quitting.\n"
	"  -w <int> : sets the initial size of the window, in pixels.\n"
	"  -t <int> : sets strategy, 1 means distributed, 2 means centralized.\n"
	"  -b <int> : sets the position of the source, 1 means randomly, 2 means not.\n"
	"  -g       : disable the gui.\n"
	"  -i <int> : use annealing method or not.\n"
	"  -e <int> : the environment, 1 means only winter 2 means winter and summer"
	"  -z <int> : sets the number of milliseconds to sleep between updates.\n"
	"  -t <int> : sets the strategy for controlling system";


Home::Home( const Color& color, double x, double y, double r ) 
	: color(color), x(x), y(y), r(r) 
{
	
	Robot::homes.push_back(this);
}
Source::Source( const Color& color, double x, double y, double r )
	: color(color), x(x), y(y), r(r) 
{
	Robot::sources.push_back(this);
	init_time=0;
}

void Source::balance()
{
	
	
	parameter_index = (parameter_index % 2);
	k = parameter_k[parameter_index];
	b = parameter_b[parameter_index];
	sleep_time =  ( real_robots * Robot::Period*1.0 / (k*k/(4.0*b)) - 8 - 10 - round_trip );
	if(sleep_time < 0)
		sleep_time =0;
	
	#if DEBUG
		printf("sleep: %ld, opt_n: %lf, real_n: %d\n",sleep_time,opt_n,real_robots);
		printf("parameter change k:%lf, b:%lf\n",k,b);
	#endif
	parameter_index++;
}

void Source::Init()
{
	id= Robot::source_id;
	Robot::source_id++;
	parameter_k = new double[2];
	parameter_b = new double[2];
	parameter_k[0]=0.4;
	parameter_k[1]=0.8;
	parameter_b[0]=0.004;
	parameter_b[1]=0.008;
	parameter_index = 0;
	k=parameter_k[parameter_index];
	b=parameter_b[parameter_index];
	p0=60;
	low=15;
	dis = hypot(Robot::WrapDistance(x-Robot::worldsize/2.0),Robot::WrapDistance(y-Robot::worldsize/2.0));
	round_trip = 2.0* dis/0.005;
	opt_n = k *k / (4.0*b) / (Robot::Period*1.0) * ( 8 + 10  + round_trip);
	//sleep_time = (long) ( real_robots * 100 / (k*k/(4.0*b)) - 8 - 10 - round_trip );
	high = (int)(k/b);
	p=p0;
	num_robots=0;
	//printf("%d,%lf,%lf,%lf\n",id,x,y,opt_n);
	for(int i=0; i<p0; i++)
	{
		Robot::Puck a;
		a.Init(this,id,x,y,r);
		Robot::pucks.push_back(a);
	}
}
void Source::delete_puck()
{
	p--;
}

bool Source::safe()
{
	return (p > (low+2) );
}


int Source::get_puck()
{
	return p;
}
int Source::update_puck()
{
	int delta_p=0;
	#if DEBUG
		printf("id:%d,p:%d",id,p);
	#endif
	if( ( p > low ) && (p < (int)(k/b)))
	{
		delta_p = ( int) (  k * p - b * p * p +0.5);
		
		p = p+delta_p;
		for(int i=0; i<delta_p; i++)
		{
			Robot::Puck a;
			a.Init(this,id,x,y,r);
			Robot::pucks.push_back(a);
		}
	}
	#if DEBUG
		printf("dp:%d,num:%d\n",delta_p,num_robots);
	#endif
	return delta_p;
}

Robot::Robot( Home* home, Source *source,
							const Pose& pose )
  : home(home),
	source(source),
	  pose(pose),
		speed(),
		see_robots(),
		see_pucks(),
		puck_held(NULL)
{
  // add myself to the static vector of all robots
	r_id = robot_id;
	robot_id++;
	pick_time =10;
	drop_time =8;
	//switch_task=false;
	max_patch_rate=-1;
	last_puck_number =-1;
	this_puck_number = -1;
	if(source == NULL && strategy == 1)
		sleep_time =0;
	else if (source != NULL && strategy == 2)
	{
		sleep_time = source->sleep_time;// (long) ( source->real_robots * 100 / (source->k*source->k/(4.0*source->b)) - 8 - 10 - source->round_trip );
		#if DEBUG
			printf("sleep: %ld\n",sleep_time);
		#endif
	}
	else{}
	max_pucks = new long[puck_count+1];
	min_pucks = new long[puck_count+1];
	for(unsigned int i=0; i<( puck_count+1 ); i++)
	{
		max_pucks[i]=0;
		min_pucks[i]=100000;
	}
	teamers = new Team[home_population+1];
	sleep_time =0;
	switch_number =0;
	count_time =0;
	fast_speed = true;
	last_home_time =-1;
	real_work_time =-1;
  population.push_back( this );
}

void Robot::Init( int argc, char** argv )
{
  // seed the random number generator with the current time
  srand48(time(NULL));
	
  // parse arguments to configure Robot static members
	int c;
	while( ( c = getopt( argc, argv, "?dh:a:p:s:f:r:c:u:b:z:t:w:i:e:g")) != -1 )
		switch( c )
			{
			case 'h':
			  home_count = atoi( optarg );
			#if DEBUG
			  	printf( "[Antix] home count: %d\n", home_count );
			#endif
			  break;

			case 'a':
			  puck_count = atoi( optarg );
				#if DEBUG
			  		printf( "[Antix] puck count: %d\n", puck_count );
				#endif
			  break;
			  
			case 'p': 
				home_population = atoi( optarg );
				#if DEBUG
					printf( "[Antix] home_population: %d\n", home_population );
				#endif
				break;
			case 'e':
				environment = atoi( optarg );
				#if DEBUG
					printf("[Antix] environment: %d\n", environment);
				#endif
				break;
				
			case 's': 
				worldsize = atof( optarg );
				#if DEBUG
					printf( "[Antix] worldsize: %.2f\n", worldsize );
				#endif
				break;
				
			case 'f': 
				fov = dtor(atof( optarg )); // degrees to radians
				#if DEBUG
					printf( "[Antix] fov: %.2f\n", fov );
				#endif
				break;
				
			case 'r': 
				range = atof( optarg );
				#if DEBUG
					printf( "[Antix] range: %.2f\n", range );
				#endif
				break;
								
      			case 'u':
				updates_max = atol( optarg );
				#if DEBUG
					printf( "[Antix] updates_max: %lu\n", (long unsigned)updates_max );
				#endif
				break;
			case 'b':
				random_position = atoi( optarg );
				#if DEBUG
					printf( "[Antix] the random position: %d\n", random_position );
				#endif
				
				break;
			case 'i':
				anneal = atoi(optarg);
				#if DEBUG
					printf( "[Antix] the aneal: %d\n", anneal);
				#endif
				break;

			case 'g':
				isgraphics = false;
				break;
				
			case 'z':
				sleep_msec = atoi( optarg );
				#if DEBUG
					printf( "[Antix] sleep_msec: %d\n", sleep_msec );
				#endif
				break;
			case 't':
				strategy = atoi(optarg);
				#if DEBUG
					printf( "[Antix] strategy: %d\n", strategy );
				#endif
				break;
				
#if GRAPHICS
			case 'w': winsize = atoi( optarg );
				#if DEBUG
					printf( "[Antix] winsize: %d\n", winsize );
				#endif
				break;

			case 'd': show_data=true;
				#if DEBUG
			  		puts( "[Antix] show data" );
				#endif
			  break;
#endif			
			case '?':
				
			  		puts( usage );
				
			  exit(0); // ok
			  break;

			default:
				fprintf( stderr, "[Antix] Option parse error.\n" );
				puts( usage );
				exit(-1); // error
			}
	
	//for(unsigned int i=0; i<puck_count; i++)
	//		source

	//for( unsigned int i=0; i<puck_count; i++ )
	  //pucks.push_back( Puck() );	
	
//#if GRAPHICS
	if(isgraphics)
	InitGraphics( argc, argv );
//#endif // GRAPHICS
}

void Robot::UpdateSensors()
{
  see_robots.clear();
  see_pucks.clear();
  closed_robot=false;
  
	// note: the following two large Fsensing operations could safely be
	// done in parallel since they do not modify any common data
	
  // first fill the robot sensor
  // check every robot in the world to see if it is detected
  FOR_EACH( it, population )
    {
      Robot* other = *it;
			
      // discard if it's the same robot
      if( other == this )
				continue;
			
      // discard if it's out of range. We put off computing the
      // hypotenuse as long as we can, as it's relatively expensive.
		
      double dx( WrapDistance( other->pose.x - pose.x ) );
			if( fabs(dx) > Robot::range )
				continue; // out of range
			
      double dy( WrapDistance( other->pose.y - pose.y ) );		
			if( fabs(dy) > Robot::range )
				continue; // out of range
			
      double range = hypot( dx, dy );
      if( range > Robot::range ) 
				continue; 
			
      // discard if it's out of field of view 
      double absolute_heading = atan2( dy, dx );
      double relative_heading = AngleNormalize((absolute_heading - pose.a) );
      if( fabs(relative_heading) > fov/2.0   ) 
				continue; 
	
			if(other->source != NULL && this->source != NULL && other->source->id == this->source->id && other->last_puck_number>0 && other->this_puck_number >0)
			{
			this->teamers[other->r_id].Set(other->this_puck_number, other->last_puck_number,other->getRealWorkTime());
				if(other->puck_held != this->puck_held)
					closed_robot = true;
			}
			see_robots.push_back( SeeRobot( other->home,
																			other->pose, 
																			other->speed, 
																			range, 
																			relative_heading,
																			other->Holding() ) );			
    }	
	seepuck_my_goal = false;
  // next fill the puck sensor
  // check every puck in the world to see if it is detected
  FOR_EACH( it, pucks )
    {      
      // discard if it's out of range. We put off computing the
      // hypotenuse as long as we can, as it's relatively expensive.
		
      double dx( WrapDistance( it->x - pose.x ) );
		if( fabs(dx) > Robot::range )
		  continue; // out of range
		
      double dy( WrapDistance( it->y - pose.y ) );		
		if( fabs(dy) > Robot::range )
		  continue; // out of range
		
      double range = hypot( dx, dy );
      if( range > Robot::range ) 
		  continue; 
		
      // discard if it's out of field of view 
      double absolute_heading = atan2( dy, dx );
      double relative_heading = AngleNormalize((absolute_heading - pose.a) );
      if( fabs(relative_heading) > fov/2.0   ) 
		  continue; 
		
			// passes all the tests, so we record a puck detection in the
			// vector
		
		if( ((source == NULL) || (source ==it->source)) && !it->home  &&!it->held)
				seepuck_my_goal = true;
			if(it->held == false && it->home == false)
			see_pucks.push_back( SeePuck( &(*it), range, relative_heading,it->held, it->home, it->source));//add zhao june 10
		}		
}

int Robot::Pickup()
{
  if( ! puck_held ) 
		FOR_EACH( it, see_pucks )
			{
				// is the puck close enough and is it not held already?
				if(it->puck != NULL && it->puck->source != NULL && (source == NULL || (source == it->puck->source)))
				if( (it->range < pickup_range) && !it->puck->held )
					{			
						if (it->puck->source->safe() &&good_to_pick(it->puck->source->id,see_pucks.size()))
						{
							// pick it up
							puck_held = it->puck;
							int tmp = 0;
							//FOR_EACH( it1, see_pucks )
							///	if(it1->held == false && it1->home == false)
							//		tmp = tmp +1;
							tmp = see_pucks.size();
							#if DEBUG
								
								if(fabs(tmp - it->puck->source->p) > 5)
									printf("[ERROR]: the %d, %d\n",tmp,it->puck->source->p);
								
							#endif	
							
							//push_queue(it->puck->source->p);
							puck_held->held = true;
							puck_held->home = false;
							source = puck_held->source;
							push_queue(tmp,source->id);
							if(fast_speed)
								source->num_robots++;
							fast_speed = false;
							
							//when a robot get a puck, then decrease the number in source
							source->delete_puck();
							return 1;
						}
						else
						{
							int tmp = see_pucks.size();
							#if DEBUG
								
								if(fabs(tmp - it->puck->source->p) > 5)
									printf("[ERROR]: the %d, %d\n",tmp,it->puck->source->p);
							#endif	
							if(source!=NULL)
							push_queue(tmp,it->puck->source->id);
							//push_queue(it->puck->source->p);
							if(source == NULL)
								return 3;
							return 2;
						}
					}		  		  
			}
	
	// already holding or nothing close enough
  return 0; 
}

bool Robot::Holding()
{
  return (bool)puck_held;
}

bool isHome(const Robot::Puck& p)
{return p.home;}

int Robot::Drop(int flag)
{
  if( puck_held || flag == 4)
	 {
		if(flag != 4)
		{
			puck_held->held = false;
			puck_held->home = true;
			pucks.remove_if(isHome);
			puck_held = NULL;	
			pucks_collected++;
			
		}
		else
		{
			#if DEBUG
				if(source!=NULL && strategy == 2)
				printf("source %d robot %d do not drop any thing!>>>>>>>\n", source->id ,r_id );
			#endif
		}
		if( ((cal() && (drand48() < 0.5)) || (isGivenUp() && (drand48() < 0.5))) && ( strategy == 1 ))
		{//strategy is 1 means the distributed method
		//only in distributed method, the robot will switch to another task
			if(source == NULL)
			{
				#if DEBUG
					printf("[ERROR] source is NULL\n");
				#endif
			}
			else
				source->num_robots--;
			fast_speed = true;
			source = NULL;// the robot will have no source that randomly search again
			clean_queue();// clean the queue
			switch_number++;// count the switch time for each robot
			last_home_time =-1;
			real_work_time =-1;
			reset_sleep_time();// initial the sleep time
			
			
			//switch_task = true;
			return 2;
		}
		if(strategy == 1)
			com_distributed();
		else
			com_centralized();
		return 1; // dropped successfully
	 }
  return 0; // nothing to drop  
}

void Robot::UpdatePose()
{
  // move according to the current speed 
  double dx = speed.v * cos(pose.a);
  double dy = speed.v * sin(pose.a);; 
  double da = speed.w;
  
  pose.x = DistanceNormalize( pose.x + dx );
  pose.y = DistanceNormalize( pose.y + dy );
  pose.a = AngleNormalize( pose.a + da );

  // if we're carrying a puck, update it's position
  if( puck_held )
	 {
		puck_held->x = pose.x;
		puck_held->y = pose.y;
	 }
}

void Robot::UpdateAll()
{
  // if we've done enough updates, exit the program
  if( updates_max > 0 && updates > updates_max )
{
	int value=0;
	if(strategy ==2)
		value = strategy;
	else
		value = strategy + anneal *2;
	printf("%d,%d,%llu\n",value,home_population, pucks_collected);
	printf("try to close the file\n");
	fclose(Robot::file_robot);
	printf("then quit\n");
	 exit(1);
}
  
  if( ! Robot::paused )
		{
			FOR_EACH( r, population )
				(*r)->UpdatePose();

			FOR_EACH( r, population )
				(*r)->UpdateSensors();

			FOR_EACH( r, population )
				(*r)->Controller();
			
			if(updates%Period  == 0)
			{
				unsigned int total = 0;
				#if WRITE
					fprintf(file_robot,"%d,",(int)updates/Period);
					FOR_EACH(s, sources)
						fprintf(file_robot,"%d,%d,",(*s)->p, ( int) (  (*s)->k * (*s)->p - (*s)->b * (*s)->p * (*s)->p +0.5));
				#endif
				FOR_EACH(s, sources)
				{	
					total = total +(*s)->num_robots;
					#if WRITE
						fprintf(file_robot,"%d,",(*s)->num_robots);
					#endif
					if(environment == 1)
					{
						if(strategy == 1 && updates ==0)
							(*s)->balance();
						//if(updates == 0)
						//	(*s)->balance();
					}
					else
					{
						if(strategy == 1)
						{
							if(updates%2500 == 0)
								(*s)->balance();
						}
						else
						{
							if(updates%2500 == 0 && updates!=0)
							{
								(*s)->balance();
							}
						}
					}
					(*s)->update_puck();
				}
				#if WRITE
					fprintf(file_robot,"%d",home_population - total);
				#endif
				
				double res[4]={0.0,0.0,0.0,0.0};
				//double res1[4]={0.0,0.0,0.0,0.0};
				int count[4]={0,0,0,0};
				for(int i=0; i<4; i++)
					realWorkTime[i]=0;
				FOR_EACH( r, population )
				{
					if((*r)->source!=NULL && (*r)->fast_speed == false)
					{
						int index =(*r)->source->id;
						if( index < 1 || index >3)
						{
							#if DEBUG
								printf("[ERROR]:index %d wrong!\n",index);
							#endif
						}
						else
						{
							res[index] = res[index] + (*r)->getWorkTime();
							//res1[index] = res1[index] + 1.0/( 1.0*(*r)->getRealWorkTime() );
							realWorkTime[index] = realWorkTime[index] + 1.0/( 1.0*(*r)->getRealWorkTime() );
							count[index] = count[index]+1;
						}
					}
				}
				#if WRITE
					for(int i=1; i<=3; i++)
						fprintf(file_robot,",%lf,%lf",res[i],realWorkTime[i]);
					fprintf(file_robot,"\n");
				#endif
				FOR_EACH(s, sources)
					if((*s)->num_robots != count[(*s)->id])
					{
						#if DEBUG
							printf("num_robots: %d != count[%d]: %d\n",(*s)->num_robots,(*s)->id,count[(*s)->id]);
						#endif
					}
					
				#if DEBUG
					printf("update over, %llu,%llu,%llu\n",puck_id,pucks_collected,(unsigned long long)updates);
				#endif
			}
			if( ( strategy == 2)&& ( environment ==2) && updates%2500 == 0)
			{//strategy 2 means the centralized method
				FOR_EACH( r, population )
					(*r)->balance_sleep_time();
			}
		}

  ++updates;
  
  // possibly snooze to save CPU and slow things down 
  if( sleep_msec > 0 )
		usleep( sleep_msec * 1e3 );
}

void Robot::Run()
{
//#if GRAPHICS
	if(isgraphics)
  UpdateGui();
//#else
	else
	{
  		while( 1 )
    		UpdateAll();
	}
//#endif
}

// wrap around torus
double Robot::WrapDistance( double d )
{
  const double halfworld( worldsize * 0.5 );
  
  if( d > halfworld )
	 d -= worldsize;
  else if( d < -halfworld )
	 d += worldsize;

  return d;
}

/** Normalize a length to within 0 to worldsize. */
double Robot::DistanceNormalize( double d )
{
	while( d < 0 ) d += worldsize;
	while( d > worldsize ) d -= worldsize;
	
	return d; 
} 

/** Normalize an angle to within +/_ M_PI. */
double Robot::AngleNormalize( double a )
{
	while( a < -M_PI ) a += 2.0*M_PI;
	while( a >  M_PI ) a -= 2.0*M_PI;	 
	return a;
}	 
